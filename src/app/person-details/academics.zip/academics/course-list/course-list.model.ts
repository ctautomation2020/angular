export interface CourseListModel {
  course_code: string;
  stream: number;
  regulation: number;
  semester: number;
  title: string;
  credit: number;
  objectives: string;
  sallot_id: number;
}
