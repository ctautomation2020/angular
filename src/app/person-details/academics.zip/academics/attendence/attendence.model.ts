export interface AttendenceModel {
  cattend_id: number;
  course_code: string;
  reg_no: number;
  date: Date;
  presence: string;
}
